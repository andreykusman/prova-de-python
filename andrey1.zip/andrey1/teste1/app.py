# Importando as bibliotecas necessárias
from flask import Flask, render_template, request, send_from_directory
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from imblearn.over_sampling import RandomOverSampler
from sklearn.datasets import make_classification
from sklearn.metrics import ConfusionMatrixDisplay
import matplotlib.pyplot as plt

# Inicialização do aplicativo Flask
app = Flask(__name__)

# Função para gerar dados localmente
def generate_data(class_sep, weights, n_informative, n_redundant, flip_y, n_features, n_clusters_per_class, n_samples, random_state):
    """
    Gera dados sintéticos usando a função make_classification do scikit-learn.
    Parameters:
    - class_sep: A separação entre as classes.
    - weights: A proporção de amostras em cada classe.
    - n_informative: O número de recursos informativos.
    - n_redundant: O número de recursos redundantes.
    - flip_y: A fração de instâncias cujo rótulo é invertido.
    - n_features: O número total de recursos.
    - n_clusters_per_class: O número de clusters por classe.
    - n_samples: O número total de amostras.
    - random_state: A semente para a geração de números aleatórios.
    Returns:
    - X_over: Features geradas.
    - y_over: Rótulos gerados.
    """
    X, y = make_classification(n_classes=2, class_sep=class_sep,
                               weights=weights, n_informative=n_informative,
                               n_redundant=n_redundant, flip_y=flip_y, n_features=n_features,
                               n_clusters_per_class=n_clusters_per_class, n_samples=n_samples,
                               random_state=random_state)
    oversample = RandomOverSampler(sampling_strategy='minority')
    X_over, y_over = oversample.fit_resample(X, y)
    return X_over, y_over

# Função para criar a matriz de confusão e salvar a imagem
def generate_confusion_matrix_image(y_test, y_pred):
    # Calcula a matriz de confusão entre os rótulos verdadeiros (y_test) e os rótulos previstos (y_pred)
    cm = confusion_matrix(y_test, y_pred)

    # Cria uma lista de classes para rótulos com base no número de classes na matriz de confusão
    classes = [str(cls) for cls in range(len(cm))]

    # Cria uma instância de ConfusionMatrixDisplay para visualizar a matriz de confusão
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=classes)

    # Plota a matriz de confusão com um esquema de cores 'viridis' e formato de valores numéricos 'd'
    disp.plot(cmap='viridis', values_format='d')

    # Salva a imagem da matriz de confusão no diretório 'static' como 'confusion_matrix.png'
    plt.savefig('static/confusion_matrix.png')


# Rota principal para a página inicial
@app.route('/')
def home():
    """
    Rota principal para renderizar a página inicial.

    Returns:
    - Renderiza a página 'home.html'.
    """
    return render_template('home.html')

# Rota para treinamento do modelo, acessada por meio de uma solicitação POST
@app.route('/train', methods=['POST'])
def train():
    """
    Rota para treinamento do modelo, acessada por meio de uma solicitação POST.

    Returns:
    - Renderiza a página 'results.html' com métricas e a matriz de confusão.
    """
    # Obtém informações do formulário
    classifier = request.form['classifier']
    parameters = request.form['parameters']
    dataset = request.form['dataset']

    # Gera dados com base no conjunto escolhido
    if dataset == 'iris':
        X_over, y_over = generate_data(class_sep=2, weights=[0.1, 0.9], n_informative=3,
                                       n_redundant=1, flip_y=0, n_features=20,
                                       n_clusters_per_class=1, n_samples=1000,
                                       random_state=10)
    elif dataset == 'digits':
        X_over, y_over = generate_data(
            class_sep=2,  # Separador entre as classes
            weights=[0.1, 0.9],  # Proporção de amostras em cada classe (10% classe 0, 90% classe 1)
            n_informative=3,  # Número de recursos informativos
            n_redundant=1,  # Número de recursos redundantes
            flip_y=0,  # Fração de instâncias cujos rótulos são invertidos
            n_features=20,  # Número total de recursos
            n_clusters_per_class=1,  # Número de clusters por classe
            n_samples=2000,  # Número total de amostras
            random_state=10  # Semente para a geração de números aleatórios (para reproducibilidade)
        )
    else:
        return 'Conjunto de dados inválido'

    # Divide os dados em conjuntos de treinamento e teste
    X_train, X_test, y_train, y_test = train_test_split(X_over, y_over, test_size=0.3, random_state=42)

    # Escolhe o classificador com base na escolha do usuário
    if classifier == 'KNN':
        clf = KNeighborsClassifier()
    elif classifier == 'SVM':
        clf = SVC()
    elif classifier == 'MLP':
        clf = MLPClassifier()
    elif classifier == 'DT':
        clf = DecisionTreeClassifier()
    elif classifier == 'RF':
        clf = RandomForestClassifier()
    else:
        return 'Classificador inválido'

    # Treina o classificador
    clf.fit(X_train, y_train)

    # Avalia o modelo usando métricas e validação cruzada
    scores = cross_val_score(clf, X_over, y_over, cv=5)
    mean_cv_score = scores.mean()

    # Realiza previsões no conjunto de teste
    y_pred = clf.predict(X_test)

    # Calcula a acurácia do modelo usando a função accuracy_score do scikit-learn
    accuracy = accuracy_score(y_test, y_pred)

    # Calcula a precisão do modelo usando a função precision_score do scikit-learn com média macro
    precision = precision_score(y_test, y_pred, average='macro')

    # Calcula o recall do modelo usando a função recall_score do scikit-learn com média macro
    recall = recall_score(y_test, y_pred, average='macro')

    # Calcula a pontuação F1 do modelo usando a função f1_score do scikit-learn com média macro
    f1 = f1_score(y_test, y_pred, average='macro')

    # Calcula a matriz de confusão do modelo usando a função confusion_matrix do scikit-learn
    cm = confusion_matrix(y_test, y_pred)

    # Gera e salva a imagem da matriz de confusão
    generate_confusion_matrix_image(y_test, y_pred)

    # Renderiza a página de resultados com as métricas e a matriz de confusão
    return render_template('results.html', classifier=classifier, parameters=parameters, dataset=dataset, accuracy=accuracy, precision=precision, recall=recall, f1=f1, cm=cm, mean_cv_score=mean_cv_score)

# Rota para servir a imagem da matriz de confusão
@app.route('/get_confusion_matrix_image')
def get_confusion_matrix_image():
    """
    Rota para servir a imagem da matriz de confusão.

    Returns:
    - Retorna a imagem da matriz de confusão.
    """
    return send_from_directory('static', 'confusion_matrix.png')

# Executa o aplicativo Flask
if __name__ == '__main__':
    app.run(debug=True)
