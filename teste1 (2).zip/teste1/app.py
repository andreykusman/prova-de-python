from flask import Flask, render_template, request
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from imblearn.over_sampling import RandomOverSampler
from sklearn.datasets import make_classification

app = Flask(__name__)

# Função para gerar dados localmente
def generate_data(class_sep, weights, n_informative, n_redundant, flip_y, n_features, n_clusters_per_class, n_samples, random_state):

    # Gera dados de classificação sintéticos usando a biblioteca sklearn.datasets
    X, y = make_classification(n_classes=2, class_sep=class_sep,
                               weights=weights, n_informative=n_informative,
                               n_redundant=n_redundant, flip_y=flip_y, n_features=n_features,
                               n_clusters_per_class=n_clusters_per_class, n_samples=n_samples,
                               random_state=random_state)

    # Cria um objeto RandomOverSampler para realizar o oversampling da classe minoritária
    oversample = RandomOverSampler(sampling_strategy='minority')

    # Aplica o oversampling aos dados originais
    X_over, y_over = oversample.fit_resample(X, y)

    # Retorna os dados sobreamostrados e seus rótulos correspondentes
    return X_over, y_over


@app.route('/')
def home():
    # Renderiza o template HTML 'home.html'
    return render_template('home.html')

@app.route('/train', methods=['POST'])
def train():
    # Recupera os valores dos campos do formulário enviados pelo usuário
    classifier = request.form['classifier']
    parameters = request.form['parameters']
    dataset = request.form['dataset']

    # Carregar o conjunto de dados
    # Verifica a opção selecionada pelo usuário e carrega o conjunto de dados correspondente.
    # Caso o usuário selecione uma opção inválida, retorna uma mensagem de erro.
    if dataset == 'iris':
        # Gera dados sintéticos para o conjunto "iris"
        # Gera 1000 amostras com 20 recursos, onde a classe minoritária representa 10% dos dados.
        # O estado aleatório é definido como 10 para garantir a reprodutibilidade.

        X_over, y_over = generate_data(class_sep=2, weights=[0.1, 0.9], n_informative=3,
                                       n_redundant=1, flip_y=0, n_features=20,
                                       n_clusters_per_class=1, n_samples=1000,
                                       random_state=10)
    elif dataset == 'digits':
        # Gera dados sintéticos para o conjunto "digits"
        # Gera 2000 amostras com 20 recursos, onde a classe minoritária representa 10% dos dados.
        # O estado aleatório é definido como 10 para garantir a reprodutibilidade.

        X_over, y_over = generate_data(class_sep=2, weights=[0.1, 0.9], n_informative=3,
                                       n_redundant=1, flip_y=0, n_features=20,
                                       n_clusters_per_class=1, n_samples=2000,
                                       random_state=10)
    else:
        return 'Conjunto de dados inválido'

    # Dividir o conjunto de dados em treinamento e teste
    X_train, X_test, y_train, y_test = train_test_split(X_over, y_over, test_size=0.3, random_state=42)

    # Inicializar o classificador
    if classifier == 'KNN':
        # Cria uma instância da classe KNeighborsClassifier
        clf = KNeighborsClassifier()
    elif classifier == 'SVM':
        # Cria uma instância da classe SVC
        clf = SVC()
    elif classifier == 'MLP':
        # Cria uma instância da classe MLPClassifier
        clf = MLPClassifier()
    elif classifier == 'DT':
        # Cria uma instância da classe DecisionTreeClassifier
        clf = DecisionTreeClassifier()
    elif classifier == 'RF':
        # Cria uma instância da classe RandomForestClassifier
        clf = RandomForestClassifier()
    else:
        # Opção de classificador inválida
        return 'Classificador inválido'

    # Treinar o classificador
    clf.fit(X_train, y_train)

    # Avaliar o classificador com validação cruzada
    scores = cross_val_score(clf, X_over, y_over, cv=5)  # Realiza validação cruzada no classificador com 5 folds
    mean_cv_score = scores.mean()  # Calcula a média das pontuações da validação cruzada

    # Avaliar o classificador no conjunto de teste
    y_pred = clf.predict(X_test)  # Preveja as rótulos das amostras de teste
    accuracy = accuracy_score(y_test, y_pred)  # Calcule a acurácia do classificador
    precision = precision_score(y_test, y_pred, average='macro')  # Calcule a precisão do classificador (média macro)
    recall = recall_score(y_test, y_pred, average='macro')  # Calcule a sensibilidade do classificador (média macro)
    f1 = f1_score(y_test, y_pred, average='macro')  # Calcule a pontuação F1 do classificador (média macro)
    cm = confusion_matrix(y_test, y_pred)  # Calcule a matriz de confusão do classificador

    return render_template('results.html', classifier=classifier, parameters=parameters, dataset=dataset, accuracy=accuracy, precision=precision, recall=recall, f1=f1, cm=cm, mean_cv_score=mean_cv_score)

if __name__ == '__main__':
    app.run(debug=True)
