from flask import Flask, render_template, request, send_from_directory
from sklearn.model_selection import train_test_split, cross_val_score
from sklearn.neighbors import KNeighborsClassifier
from sklearn.svm import SVC
from sklearn.neural_network import MLPClassifier
from sklearn.tree import DecisionTreeClassifier
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import accuracy_score, precision_score, recall_score, f1_score, confusion_matrix
from imblearn.over_sampling import RandomOverSampler
from sklearn.datasets import make_classification
from sklearn.metrics import ConfusionMatrixDisplay
import os
import matplotlib.pyplot as plt

app = Flask(__name__)

# Função para gerar dados localmente
def generate_data(class_sep, weights, n_informative, n_redundant, flip_y, n_features, n_clusters_per_class, n_samples, random_state):
    X, y = make_classification(n_classes=2, class_sep=class_sep,
                               weights=weights, n_informative=n_informative,
                               n_redundant=n_redundant, flip_y=flip_y, n_features=n_features,
                               n_clusters_per_class=n_clusters_per_class, n_samples=n_samples,
                               random_state=random_state)
    oversample = RandomOverSampler(sampling_strategy='minority')
    X_over, y_over = oversample.fit_resample(X, y)
    return X_over, y_over

# Função para criar a matriz de confusão e salvar a imagem
def generate_confusion_matrix_image(y_test, y_pred):
    cm = confusion_matrix(y_test, y_pred)
    classes = [str(cls) for cls in range(len(cm))]
    disp = ConfusionMatrixDisplay(confusion_matrix=cm, display_labels=classes)
    disp.plot(cmap='viridis', values_format='d')
    plt.savefig('static/confusion_matrix.png')

@app.route('/')
def home():
    return render_template('home.html')

@app.route('/train', methods=['POST'])
def train():
    classifier = request.form['classifier']
    parameters = request.form['parameters']
    dataset = request.form['dataset']

    if dataset == 'iris':
        X_over, y_over = generate_data(class_sep=2, weights=[0.1, 0.9], n_informative=3,
                                       n_redundant=1, flip_y=0, n_features=20,
                                       n_clusters_per_class=1, n_samples=1000,
                                       random_state=10)
    elif dataset == 'digits':
        X_over, y_over = generate_data(class_sep=2, weights=[0.1, 0.9], n_informative=3,
                                       n_redundant=1, flip_y=0, n_features=20,
                                       n_clusters_per_class=1, n_samples=2000,
                                       random_state=10)
    else:
        return 'Conjunto de dados inválido'

    X_train, X_test, y_train, y_test = train_test_split(X_over, y_over, test_size=0.3, random_state=42)

    if classifier == 'KNN':
        clf = KNeighborsClassifier()
    elif classifier == 'SVM':
        clf = SVC()
    elif classifier == 'MLP':
        clf = MLPClassifier()
    elif classifier == 'DT':
        clf = DecisionTreeClassifier()
    elif classifier == 'RF':
        clf = RandomForestClassifier()
    else:
        return 'Classificador inválido'

    clf.fit(X_train, y_train)

    scores = cross_val_score(clf, X_over, y_over, cv=5)
    mean_cv_score = scores.mean()

    y_pred = clf.predict(X_test)
    accuracy = accuracy_score(y_test, y_pred)
    precision = precision_score(y_test, y_pred, average='macro')
    recall = recall_score(y_test, y_pred, average='macro')
    f1 = f1_score(y_test, y_pred, average='macro')
    cm = confusion_matrix(y_test, y_pred)

    generate_confusion_matrix_image(y_test, y_pred)

    return render_template('results.html', classifier=classifier, parameters=parameters, dataset=dataset, accuracy=accuracy, precision=precision, recall=recall, f1=f1, cm=cm, mean_cv_score=mean_cv_score)

# Rota para servir a imagem da matriz de confusão
@app.route('/get_confusion_matrix_image')
def get_confusion_matrix_image():
    return send_from_directory('static', 'confusion_matrix.png')

if __name__ == '__main__':
    app.run(debug=True)
